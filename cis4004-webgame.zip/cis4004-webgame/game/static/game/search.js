// Function to search for games in your local database
document.getElementById("searchInput").addEventListener("input", function (e) {
    searchGames(e.target.value.trim());
});

function searchGames(query) {
    // Perform an API call to fetch games based on the search query
    fetch(`/api/games/?title=${query}`)
        .then(response => response.json())
        .then(data => {
            const gamesBody = document.getElementById("gamesBody");
            gamesBody.innerHTML = ''; // Clear the previous results
            data.forEach(game => {
                const row = document.createElement("tr");
                row.innerHTML = `
                    <td>${game.title}</td>
                    <td>${game.developer}</td>
                    <td>${game.year}</td>
                    <td><button onclick="editGame(${game.id})">Edit</button></td>
                `;
                gamesBody.appendChild(row);
            });
        })
        .catch(error => console.error('Error fetching games:', error));
}

function searchOnlineGame() {
    const query = document.getElementById("webGameSearchInput").value.trim();

    if (query) {
        fetch(`/api/search/?query=${encodeURIComponent(query)}`)
            .then(response => response.json())
            .then(data => {
                const webSearchResults = document.getElementById("webSearchResults");
                webSearchResults.innerHTML = ''; // Clear previous results

                let resultsHtml = "<h3>Search Results:</h3>";

                if (data.steam.length > 0) {
                    resultsHtml += "<h4>Steam</h4><ul>";
                    data.steam.forEach(game => {
                        resultsHtml += `<li><a href="${game.url}" target="_blank">${game.title}</a></li>`;
                    });
                    resultsHtml += "</ul>";
                } else {
                    resultsHtml += "<p>No results found on Steam.</p>";
                }

                if (data.itch.length > 0) {
                    resultsHtml += "<h4>Itch.io</h4><ul>";
                    data.itch.forEach(game => {
                        resultsHtml += `<li><a href="${game.url}" target="_blank">${game.title}</a></li>`;
                    });
                    resultsHtml += "</ul>";
                } else {
                    resultsHtml += "<p>No results found on Itch.io.</p>";
                }

                webSearchResults.innerHTML = resultsHtml;
            })
            .catch(error => {
                console.error('Error:', error);
                document.getElementById("webSearchResults").innerHTML = "<p>Error occurred while fetching results.</p>";
            });
    } else {
        alert("Please enter a search term.");
    }
}
