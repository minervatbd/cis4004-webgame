from django.shortcuts import render
import requests
from bs4 import BeautifulSoup
from django.http import JsonResponse

# Render views
def main(request):
    return render(request, 'game/main.html')

def games(request):
    return render(request, 'game/games.html')

def register(request):
    return render(request, 'game/register.html')

def collection(request):
    return render(request, 'game/collection.html')

